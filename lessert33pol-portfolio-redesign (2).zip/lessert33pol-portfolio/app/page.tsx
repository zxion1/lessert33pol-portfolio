import { About } from '@/components/portfolio/about'
import { Bots } from '@/components/portfolio/bots'
import { BoxPvp } from '@/components/portfolio/boxpvp'
import { Contact } from '@/components/portfolio/contact'
import { DiscordCopyProvider } from '@/components/portfolio/discord-copy-provider'
import { Experience } from '@/components/portfolio/experience'
import { Gamemodes } from '@/components/portfolio/gamemodes'
import { PageEffects } from '@/components/portfolio/page-effects'
import { Reveal } from '@/components/portfolio/reveal'
import { Hero } from '@/components/portfolio/hero'
import { Lifesteal } from '@/components/portfolio/lifesteal'
import { TechMarquee } from '@/components/portfolio/tech-marquee'
import { Navbar } from '@/components/portfolio/navbar'
import { Skills } from '@/components/portfolio/skills'
import { Starfield } from '@/components/portfolio/starfield'

export default function Page() {
  return (
    <DiscordCopyProvider>
      <div className="relative min-h-screen overflow-x-clip">
        <div aria-hidden="true" className="pointer-events-none fixed inset-0 -z-10">
          <Starfield />
          <div className="neon-grid absolute inset-0 opacity-70" />
          <div className="absolute -top-48 left-1/2 size-[46rem] -translate-x-1/2 rounded-full bg-[#18e0ff]/[0.07] blur-[160px]" />
          <div className="absolute top-[40%] -right-48 size-[34rem] rounded-full bg-[#8b5cf6]/[0.08] blur-[160px]" />
          <div className="absolute -bottom-48 -left-40 size-[32rem] rounded-full bg-[#18e0ff]/[0.05] blur-[160px]" />
        </div>
        <PageEffects />
        <Navbar />
        <main>
          <Hero />
          <TechMarquee />
          <Reveal><About /></Reveal>
          <Reveal><Gamemodes /></Reveal>
          <Reveal><BoxPvp /></Reveal>
          <Reveal><Lifesteal /></Reveal>
          <Reveal><Bots /></Reveal>
          <Reveal><Skills /></Reveal>
          <Reveal><Experience /></Reveal>
          <Reveal><Contact /></Reveal>
        </main>
      </div>
    </DiscordCopyProvider>
  )
}
