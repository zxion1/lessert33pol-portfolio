import { Blocks, Code2, Gauge, Search } from 'lucide-react'
import { SectionHeading } from './section-heading'

const traits = [
  { icon: Gauge, tag: '01 / ADAPT', title: 'Adapts Rapidly', body: 'Picks up new APIs, plugin hooks, and libraries within days.' },
  { icon: Search, tag: '02 / DEBUG', title: 'Trace-Driven Fixes', body: 'Investigates stack traces, logs, and server configs instead of guessing.' },
  { icon: Code2, tag: '03 / SKRIPT', title: 'Clean Skript Logic', body: 'Modular, readable code routines that keep server tick rates at a steady 20.0 TPS.' },
  { icon: Blocks, tag: '04 / BUILD', title: 'Built From Scratch', body: "Custom-tailored configurations built for each server owner's specific vision." },
]

export function About() {
  return (
    <section id="about" aria-labelledby="about-title" className="px-4 py-20 md:py-28">
      <div className="mx-auto max-w-6xl">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.1fr] lg:gap-16">
          <div>
            <SectionHeading
              id="about-title"
              index="01"
              eyebrow="About"
              title={
                <>
                  New to the scene. <span className="text-violet-300">Not new to the code.</span>
                </>
              }
              description="I'm a self-taught, hands-on builder who's newer to the public community but has been writing Skripts, configuring servers, and shipping Python bots for a while. I want to know why a system works before I touch it, so the things I build stay stable after launch."
            />
            <div className="glass -mt-4 max-w-md bg-black/30 p-4 font-mono text-[11px] leading-relaxed text-muted-foreground">
              <p className="mb-2 text-foreground">
                <span className="text-cyan-300">$</span> tail -f latest.log
              </p>
              <p>[INFO] Loaded 42 modular routines</p>
              <p>[INFO] Vault economy hooked</p>
              <p>
                [INFO] TPS: <span className="text-cyan-300">20.0</span> · MSPT: <span className="text-cyan-300">11.4</span>
              </p>
            </div>
          </div>

          <ul className="grid gap-4 sm:grid-cols-2">
            {traits.map(({ icon: Icon, tag, title, body }) => (
              <li key={title} className="glass glass-hover p-5">
                <div className="mb-4 flex items-center justify-between">
                  <span className="inline-flex size-9 items-center justify-center rounded-md border border-cyan-400/20 bg-cyan-400/10 text-cyan-300">
                    <Icon className="size-4" aria-hidden="true" />
                  </span>
                  <span className="font-mono text-[10px] tracking-widest text-muted-foreground">{tag}</span>
                </div>
                <h3 className="mb-1.5 font-semibold">{title}</h3>
                <p className="text-sm leading-relaxed text-muted-foreground">{body}</p>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}
