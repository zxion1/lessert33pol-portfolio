import { Bot, LayoutGrid, RefreshCw } from 'lucide-react'
import { SectionHeading } from './section-heading'

const bars = [40, 60, 45, 75, 50, 85, 65]

function MiniDashboard() {
  return (
    <div className="mt-1 mb-4 flex gap-3 rounded-lg border border-white/10 bg-black/40 p-3">
      <div className="flex flex-col gap-2 pt-1" aria-hidden="true">
        <span className="size-3 rounded-full bg-violet-500" />
        <span className="size-3 rounded-full bg-white/10" />
        <span className="size-3 rounded-full bg-white/10" />
        <span className="size-3 rounded-full bg-white/10" />
      </div>
      <div className="min-w-0 flex-1 space-y-2">
        <div className="grid grid-cols-3 gap-2 font-mono">
          {[
            ['MEMBERS', '1.2k'],
            ['TICKETS', '14'],
            ['UPTIME', '99%'],
          ].map(([label, value]) => (
            <div key={label} className="rounded-md border border-white/10 bg-white/[0.03] p-2">
              <p className="text-[8px] tracking-wider text-muted-foreground">{label}</p>
              <p className="text-sm font-semibold text-cyan-300">{value}</p>
            </div>
          ))}
        </div>
        <div className="flex h-14 items-end gap-1.5 rounded-md border border-white/10 bg-white/[0.03] p-2" aria-hidden="true">
          {bars.map((h, i) => (
            <span key={i} className="flex-1 rounded-sm bg-gradient-to-t from-cyan-500/60 to-violet-400/60" style={{ height: `${h}%` }} />
          ))}
        </div>
        <div className="flex items-center justify-between rounded-md border border-white/10 bg-white/[0.03] px-2.5 py-1.5 font-mono text-[9px] text-muted-foreground">
          auto_role.enabled
          <span className="relative inline-block h-3.5 w-6 rounded-full bg-cyan-400" aria-hidden="true">
            <span className="absolute top-0.5 right-0.5 size-2.5 rounded-full bg-white" />
          </span>
        </div>
      </div>
    </div>
  )
}

const bots = [
  {
    icon: Bot,
    title: 'Any Bot Type You Need',
    command: '/ticket open',
    features: ['Clan stat lookups', 'Support tickets with transcript exports', 'Moderation utilities', 'Custom commands'],
  },
  {
    icon: LayoutGrid,
    title: 'Web Dashboards',
    command: 'dashboard.dev',
    wip: true,
    dashboard: true,
    note: 'I build working web control panels for bots: toggles, stats, and config pages. My frontend skills are still leveling up, and every panel I ship is a little sharper than the last.',
  },
  {
    icon: RefreshCw,
    title: 'Minecraft & Discord Sync',
    command: '/sync ranks',
    features: ['Webhook relays for server chat', 'Live arena kill feeds', 'Player rank synchronization', 'Punishment logging'],
  },
] as const

export function Bots() {
  return (
    <section id="bots" aria-labelledby="bots-title" className="px-4 py-20 md:py-28">
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          id="bots-title"
          index="05"
          eyebrow="Discord Bots"
          title={
            <>
              Custom <span className="text-violet-300">Python Discord bots.</span>
            </>
          }
          description="Built from scratch in Python to match your community's needs."
        />

        <ul className="grid gap-4 md:grid-cols-3">
          {bots.map((bot) => {
            const Icon = bot.icon
            return (
              <li key={bot.title} className="glass glass-hover flex flex-col overflow-hidden hover:border-violet-400/30">
                <div className="flex items-center gap-2 border-b border-white/[0.06] bg-black/30 px-5 py-3">
                  <span className="size-2.5 rounded-full bg-white/10" aria-hidden="true" />
                  <span className="size-2.5 rounded-full bg-white/10" aria-hidden="true" />
                  <span className="size-2.5 rounded-full bg-cyan-400/70" aria-hidden="true" />
                  <code className="ml-auto font-mono text-xs text-cyan-300">{bot.command}</code>
                </div>
                <div className="flex flex-1 flex-col p-6">
                  <div className="mb-5 flex items-center justify-between">
                    <span className="inline-flex size-11 items-center justify-center rounded-lg border border-violet-400/25 bg-violet-400/10 text-violet-300">
                      <Icon className="size-5" aria-hidden="true" />
                    </span>
                    {'wip' in bot && (
                      <span className="inline-flex items-center gap-1.5 rounded-full border border-amber-400/30 bg-amber-400/10 px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider text-amber-300">
                        <span className="size-1.5 rounded-full bg-amber-400" aria-hidden="true" />
                        Work in progress
                      </span>
                    )}
                  </div>
                  <h3 className="mb-4 text-lg font-semibold">{bot.title}</h3>
                  {'features' in bot && (
                    <ul className="space-y-2.5">
                      {bot.features.map((feature) => (
                        <li key={feature} className="flex items-start gap-2.5 text-sm text-muted-foreground">
                          <span className="mt-1.5 size-1.5 shrink-0 rounded-sm bg-cyan-400" aria-hidden="true" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  )}
                  {'dashboard' in bot && (
                    <>
                      <MiniDashboard />
                      <p className="text-sm leading-relaxed text-muted-foreground">{bot.note}</p>
                    </>
                  )}
                </div>
              </li>
            )
          })}
        </ul>
      </div>
    </section>
  )
}
