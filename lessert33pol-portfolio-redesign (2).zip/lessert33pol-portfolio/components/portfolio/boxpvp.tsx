import { Coins, Pickaxe, ShieldCheck, Swords } from 'lucide-react'
import { SectionHeading } from './section-heading'

const pillars = [
  {
    icon: Pickaxe,
    step: 'STAGE 01',
    title: 'Tiered Mines & Drop Rates',
    body: 'Custom tiered mine regeneration loops with dynamic drop rates that scale as players climb, so early mines stay useful and late mines feel earned.',
    tags: ['Regen Loops', 'Mine Tiers', 'Dynamic Drops'],
  },
  {
    icon: Coins,
    step: 'STAGE 02',
    title: 'Pickaxe Upgrades & Token Shops',
    body: 'Pickaxe upgrade menus and GUI token shops written as modular Skript routines, all hooked into one Vault-backed economy.',
    tags: ['Upgrade GUIs', 'Token Shops', 'Sell Shops', 'Vault'],
  },
  {
    icon: Swords,
    step: 'STAGE 03',
    title: 'Combat & Arena Balancing',
    body: 'Custom PvP zones, anti-clean mechanics, spawn protection, combat-tag integrations, and balanced armor sets.',
    tags: ['PvP Zones', 'Anti-Clean', 'Combat Tag', 'Armor Sets'],
  },
  {
    icon: ShieldCheck,
    step: 'STAGE 04',
    title: 'Server Optimization & Security',
    body: 'Lag-free entity handling, exploit prevention, optimized tick rates, and comprehensive LuckPerms permission trees.',
    tags: ['Entities', 'Exploit Prevention', 'TPS', 'LuckPerms'],
  },
]

export function BoxPvp() {
  return (
    <section id="boxpvp" aria-labelledby="boxpvp-title" className="px-4 py-20 md:py-28">
      <div className="mx-auto max-w-6xl">
        <div className="glass relative overflow-hidden border-cyan-400/15 p-6 md:p-12">
          <div aria-hidden="true" className="absolute -top-32 -left-24 size-96 rounded-full bg-cyan-500/15 blur-[100px]" />
          <div aria-hidden="true" className="absolute -right-24 -bottom-32 size-96 rounded-full bg-violet-500/15 blur-[100px]" />

          <div className="relative">
            <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
              <SectionHeading
                id="boxpvp-title"
                index="03"
                eyebrow="BoxPvP"
                title={
                  <>
                    BoxPvP, built <span className="text-neon">from the first mine up.</span>
                  </>
                }
                description="From the first mine to the last permission node. I write the Skripts, balance the numbers, and patch the exploits myself."
              />
              <dl className="mb-12 grid shrink-0 grid-cols-3 gap-3 md:w-80">
                {[
                  ['100%', 'Custom'],
                  ['20.0', 'TPS'],
                  ['0', 'Templates'],
                ].map(([value, label]) => (
                  <div key={label} className="rounded-lg border border-white/10 bg-black/30 p-3 text-center">
                    <dt className="sr-only">{label}</dt>
                    <dd className="font-mono text-xl font-bold text-cyan-300">{value}</dd>
                    <dd className="mt-1 text-[11px] uppercase tracking-wider text-muted-foreground">{label}</dd>
                  </div>
                ))}
              </dl>
            </div>

            <ol className="grid gap-4 md:grid-cols-2">
              {pillars.map(({ icon: Icon, step, title, body, tags }) => (
                <li key={title} className="glass glass-hover group bg-black/30 p-6 md:p-7">
                  <div className="mb-5 flex items-center justify-between">
                    <span className="inline-flex size-12 items-center justify-center rounded-lg border border-cyan-400/25 bg-cyan-400/10 text-cyan-300 transition-shadow group-hover:shadow-[0_0_24px_-2px_rgba(24,224,255,0.55)]">
                      <Icon className="size-6" aria-hidden="true" />
                    </span>
                    <span className="font-mono text-xs tracking-widest text-violet-300/80">{step}</span>
                  </div>
                  <h3 className="mb-2 text-lg font-semibold md:text-xl">{title}</h3>
                  <p className="mb-5 leading-relaxed text-muted-foreground">{body}</p>
                  <ul className="flex flex-wrap gap-2" aria-label={`${title} features`}>
                    {tags.map((tag) => (
                      <li
                        key={tag}
                        className="rounded-md border border-white/10 bg-white/[0.04] px-2.5 py-1 font-mono text-[11px] text-foreground/80"
                      >
                        {tag}
                      </li>
                    ))}
                  </ul>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </div>
    </section>
  )
}
