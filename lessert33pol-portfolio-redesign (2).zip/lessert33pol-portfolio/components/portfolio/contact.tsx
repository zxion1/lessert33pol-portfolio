'use client'

import { Check, Copy, MessageSquare } from 'lucide-react'
import { DISCORD_USERNAME, useDiscordCopy } from './discord-copy-provider'

export function Contact() {
  const { copyDiscord, copied } = useDiscordCopy()

  return (
    <>
      <section id="contact" aria-labelledby="contact-title" className="px-4 py-20 md:py-28">
        <div className="mx-auto max-w-4xl text-center">
          <p className="mb-6 flex items-center justify-center gap-4 font-mono text-[11px] uppercase tracking-[0.25em] text-cyan-300">
            <span aria-hidden="true" className="h-px w-12 bg-gradient-to-r from-transparent to-cyan-400/40" />
            <span>
              <span className="text-muted-foreground">08.</span> // Open for commissions
            </span>
            <span aria-hidden="true" className="h-px w-12 bg-gradient-to-l from-transparent to-cyan-400/40" />
          </p>
          <h2 id="contact-title" className="text-balance text-4xl font-bold tracking-tight md:text-6xl">
            Have a project <span className="text-neon">in mind?</span>
          </h2>
          <p className="mx-auto mt-5 max-w-xl text-pretty leading-relaxed text-muted-foreground md:text-lg">
            {"Whether you need a custom bot, a web panel, or a full Minecraft setup, message me on Discord."}
          </p>

          <button
            type="button"
            onClick={copyDiscord}
            aria-label={`Copy Discord username ${DISCORD_USERNAME} to clipboard`}
            className="glass group mx-auto mt-10 flex w-full max-w-md items-center gap-4 p-4 text-left transition-all duration-300 hover:-translate-y-1 hover:border-violet-400/40 hover:shadow-[0_20px_50px_-20px_rgba(167,139,250,0.45)] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-violet-400 md:p-5"
          >
            <span className="inline-flex size-12 shrink-0 items-center justify-center rounded-lg bg-[#5865F2] text-white shadow-[0_0_24px_-4px_rgba(88,101,242,0.7)]">
              <MessageSquare className="size-6" aria-hidden="true" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                Discord
              </span>
              <span className="block truncate font-mono text-lg font-semibold text-foreground">
                {DISCORD_USERNAME}
              </span>
            </span>
            <span
              className={`inline-flex items-center gap-1.5 rounded-md border px-3 py-2 text-sm font-medium transition-colors ${
                copied
                  ? 'border-cyan-400/40 bg-cyan-400/15 text-cyan-300'
                  : 'border-white/10 bg-white/5 text-foreground group-hover:border-violet-400/40 group-hover:text-violet-200'
              }`}
              aria-hidden="true"
            >
              {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
              {copied ? 'Copied' : 'Copy'}
            </span>
          </button>
        </div>
      </section>

      <footer className="border-t border-white/[0.06] px-4 py-10">
        <div className="mx-auto flex max-w-6xl flex-col gap-8 md:flex-row md:items-start md:justify-between">
          <div className="max-w-xs">
            <p className="flex items-center gap-2 font-semibold">
              <span className="relative flex size-2" aria-hidden="true">
                <span className="absolute inline-flex size-full animate-ping rounded-full bg-cyan-400 opacity-50" />
                <span className="relative inline-flex size-2 rounded-full bg-cyan-400" />
              </span>
              Lessert33pol
            </p>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              Minecraft Developer &amp; Python Bot Coder. Custom gamemodes, modular Skript routines, and Discord bots.
            </p>
          </div>
          <nav aria-label="Footer" className="grid grid-cols-2 gap-x-10 gap-y-2 font-mono text-xs uppercase tracking-wider text-muted-foreground sm:grid-cols-4">
            {[
              ['About', '#about'],
              ['Gamemodes', '#gamemodes'],
              ['BoxPvP', '#boxpvp'],
              ['Lifesteal', '#lifesteal'],
              ['Discord Bots', '#bots'],
              ['Skills', '#skills'],
              ['Experience', '#experience'],
              ['Contact', '#contact'],
            ].map(([label, href]) => (
              <a key={href} href={href} className="transition-colors hover:text-cyan-300">
                {label}
              </a>
            ))}
          </nav>
        </div>
        <div className="mx-auto mt-8 flex max-w-6xl items-center justify-between border-t border-white/[0.06] pt-6 font-mono text-[11px] text-muted-foreground">
          <p>{'© 2026 Lessert33pol'}</p>
          <a href="#home" className="transition-colors hover:text-cyan-300">
            Back to top {'↑'}
          </a>
        </div>
      </footer>
    </>
  )
}
