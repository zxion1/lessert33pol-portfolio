'use client'

import { CheckCircle2 } from 'lucide-react'
import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react'

export const DISCORD_USERNAME = 'lessert33pol'

type DiscordCopyContextValue = {
  copyDiscord: () => void
  copied: boolean
}

const DiscordCopyContext = createContext<DiscordCopyContextValue | null>(null)

export function useDiscordCopy() {
  const context = useContext(DiscordCopyContext)
  if (!context) throw new Error('useDiscordCopy must be used within DiscordCopyProvider')
  return context
}

async function writeToClipboard(text: string) {
  try {
    await navigator.clipboard.writeText(text)
  } catch {
    const textarea = document.createElement('textarea')
    textarea.value = text
    textarea.setAttribute('readonly', '')
    textarea.style.position = 'fixed'
    textarea.style.opacity = '0'
    document.body.appendChild(textarea)
    textarea.select()
    document.execCommand('copy')
    document.body.removeChild(textarea)
  }
}

export function DiscordCopyProvider({ children }: { children: React.ReactNode }) {
  const [copied, setCopied] = useState(false)
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const copyDiscord = useCallback(async () => {
    await writeToClipboard(DISCORD_USERNAME)
    setCopied(true)
    if (timeoutRef.current) clearTimeout(timeoutRef.current)
    timeoutRef.current = setTimeout(() => setCopied(false), 2400)
  }, [])

  useEffect(() => {
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current)
    }
  }, [])

  return (
    <DiscordCopyContext.Provider value={{ copyDiscord, copied }}>
      {children}
      <div
        role="status"
        aria-live="polite"
        className="pointer-events-none fixed inset-x-0 bottom-6 z-[60] flex justify-center px-4"
      >
        <div
          className={`glass flex items-center gap-3 border-cyan-400/30 bg-[#07111a]/90 px-5 py-3 shadow-[0_10px_40px_-10px_rgba(24,224,255,0.5)] transition-all duration-300 ${
            copied ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'
          }`}
        >
          <CheckCircle2 className="size-5 text-cyan-400" aria-hidden="true" />
          <p className="text-sm text-foreground">
            {copied ? (
              <>Copied to clipboard! <span className="font-mono text-cyan-300">{DISCORD_USERNAME}</span></>
            ) : null}
          </p>
        </div>
      </div>
    </DiscordCopyContext.Provider>
  )
}
