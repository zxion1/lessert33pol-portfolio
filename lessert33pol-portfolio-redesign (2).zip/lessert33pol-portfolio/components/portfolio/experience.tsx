import { Compass, Crown, Gem, ShieldCheck, Snowflake, Swords, Wrench } from 'lucide-react'
import { SectionHeading } from './section-heading'

const leadership = [
  {
    icon: Crown,
    server: 'WhirlpoolMC',
    role: 'Founder',
    body: 'Built server infrastructure, custom Skripts, and economies from scratch.',
  },
  {
    icon: Wrench,
    server: 'MineGold MC',
    role: 'Manager',
    body: 'Supervised the staff team, managed ticket queues, and ensured daily stability.',
  },
  {
    icon: ShieldCheck,
    server: 'WolfMC',
    role: 'Admin',
    body: 'Handled in-game moderation, investigated rule breaks, and assisted with plugin testing.',
  },
]

const staff = [
  { icon: Gem, server: 'Prism SMP', role: 'Moderator', body: 'Monitored chat channels, resolved disputes, and handled rule enforcement.' },
  { icon: Swords, server: 'Apex BoxPvP', role: 'Moderator', body: 'Handled support queues, logged exploit reports, and monitored combat balance.' },
  { icon: Compass, server: 'Horizon Network', role: 'Helper', body: 'Guided new players, answered command questions, and documented bugs.' },
  { icon: Snowflake, server: 'Frostbite Network', role: 'Helper', body: 'Welcomed newcomers, assisted in chat, and forwarded player issues to senior staff.' },
]

export function Experience() {
  return (
    <section id="experience" aria-labelledby="experience-title" className="px-4 py-20 md:py-28">
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          id="experience-title"
          index="07"
          eyebrow="Experience"
          title="Experience"
          description="Seven servers across the staff ladder, from helper to founder. Knowing how a server runs day to day shapes how I build one."
        />

        <p className="mb-4 font-mono text-xs uppercase tracking-[0.25em] text-muted-foreground">Leadership</p>
        <ul className="grid gap-4 md:grid-cols-3">
          {leadership.map(({ icon: Icon, server, role, body }) => (
            <li key={server} className="glass glass-hover p-6">
              <div className="mb-5 flex items-center justify-between">
                <span className="inline-flex size-10 items-center justify-center rounded-md border border-cyan-400/25 bg-cyan-400/10 text-cyan-300">
                  <Icon className="size-5" aria-hidden="true" />
                </span>
                <span className="font-mono text-[11px] uppercase tracking-wider text-cyan-300">{role}</span>
              </div>
              <h3 className="text-lg font-semibold tracking-tight">{server}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{body}</p>
            </li>
          ))}
        </ul>

        <p className="mt-10 mb-4 font-mono text-xs uppercase tracking-[0.25em] text-muted-foreground">Staff roles</p>
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {staff.map(({ icon: Icon, server, role, body }) => (
            <li key={server} className="glass glass-hover p-5">
              <div className="mb-4 flex items-center justify-between">
                <Icon className="size-4 text-cyan-300" aria-hidden="true" />
                <span className="font-mono text-[10px] uppercase tracking-wider text-muted-foreground">{role}</span>
              </div>
              <h3 className="text-sm font-semibold">{server}</h3>
              <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">{body}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
