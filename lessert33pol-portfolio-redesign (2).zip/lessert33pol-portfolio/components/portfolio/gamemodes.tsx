import { ArrowRight, Heart, Pickaxe } from 'lucide-react'
import { SectionHeading } from './section-heading'

const modes = [
  {
    icon: Pickaxe,
    tag: 'MODE / BOXPVP',
    title: 'BoxPvP Showcase',
    href: '#boxpvp',
    points: [
      'Custom tiered mine regeneration loops',
      'Dynamic drop rates',
      'Pickaxe upgrades',
      'GUI token shops',
      'Anti-clean arena barriers',
      'Balanced armor curves',
    ],
    styles: {
      card: 'hover:border-cyan-400/35 hover:shadow-[0_24px_60px_-28px_rgba(24,224,255,0.55)]',
      icon: 'border-cyan-400/25 bg-cyan-400/10 text-cyan-300',
      tag: 'text-cyan-300',
      glow: 'bg-cyan-500/20',
    },
  },
  {
    icon: Heart,
    tag: 'MODE / LIFESTEAL',
    title: 'Lifesteal SMP Showcase',
    href: '#lifesteal',
    points: [
      'Heart-steal transfer on kill',
      'Max-heart limits',
      'Death ban / spectator rules',
      'Tiered craftable revive beacons',
      'Anti-dupe protections',
      'Combat-log protections',
    ],
    styles: {
      card: 'hover:border-rose-400/35 hover:shadow-[0_24px_60px_-28px_rgba(244,63,94,0.55)]',
      icon: 'border-rose-400/25 bg-rose-400/10 text-rose-300',
      tag: 'text-rose-300',
      glow: 'bg-rose-500/20',
    },
  },
]

export function Gamemodes() {
  return (
    <section id="gamemodes" aria-labelledby="gamemodes-title" className="px-4 py-20 md:py-28">
      <div className="mx-auto max-w-6xl">
        <SectionHeading
          id="gamemodes-title"
          index="02"
          eyebrow="Gamemodes"
          title={
            <>
              Gamemode <span className="text-neon">architecture.</span>
            </>
          }
          description="Two gamemodes I build end-to-end. Each module is its own Skript routine, wired into a shared Vault economy and LuckPerms setup."
        />

        <ul className="grid gap-4 md:grid-cols-2">
          {modes.map(({ icon: Icon, tag, title, href, points, styles }) => (
            <li
              key={title}
              className={`glass group relative flex flex-col overflow-hidden p-6 transition-all duration-300 hover:-translate-y-1 md:p-7 ${styles.card}`}
            >
              <div
                aria-hidden="true"
                className={`absolute -top-20 -right-20 size-48 rounded-full opacity-0 blur-3xl transition-opacity duration-500 group-hover:opacity-100 ${styles.glow}`}
              />
              <div className="relative mb-6 flex items-center justify-between">
                <span className={`inline-flex size-11 items-center justify-center rounded-lg border ${styles.icon}`}>
                  <Icon className="size-5" aria-hidden="true" />
                </span>
                <span className={`font-mono text-[11px] tracking-widest ${styles.tag}`}>{tag}</span>
              </div>

              <h3 className="relative mb-5 text-xl font-semibold">{title}</h3>

              <ul className="relative grid flex-1 grid-cols-2 gap-2">
                {points.map((point, i) => (
                  <li
                    key={point}
                    className="flex items-start gap-3 rounded-md border border-white/[0.06] bg-black/30 px-3 py-2.5 text-sm text-foreground/90"
                  >
                    <span className="mt-0.5 font-mono text-[10px] text-muted-foreground">{String(i + 1).padStart(2, '0')}</span>
                    {point}
                  </li>
                ))}
              </ul>

              <a
                href={href}
                className={`relative mt-6 inline-flex items-center gap-1.5 self-start font-mono text-xs uppercase tracking-wider transition-colors hover:text-foreground ${styles.tag}`}
              >
                Open the full breakdown
                <ArrowRight className="size-3.5 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
                <span className="sr-only">{` for ${title}`}</span>
              </a>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
