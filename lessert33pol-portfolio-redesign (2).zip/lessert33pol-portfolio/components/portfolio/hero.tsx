'use client'

import { ArrowUpRight } from 'lucide-react'
import { useDiscordCopy } from './discord-copy-provider'

export function Hero() {
  const { copyDiscord } = useDiscordCopy()

  return (
    <section id="home" aria-labelledby="hero-title" className="relative px-4 pt-28 pb-16 md:pt-32 md:pb-24">
      <div className="mx-auto max-w-4xl text-center">
        {/* avatar */}
        <div className="relative mx-auto mb-10 grid size-24 place-items-center">
          <div
            aria-hidden="true"
            className="absolute top-1/2 left-1/2 size-80 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[radial-gradient(circle,rgba(24,224,255,0.12),transparent_65%)]"
          />
          <img
            src="/images/avatar.png"
            alt="Lessert33pol"
            width={96}
            height={96}
            className="relative size-24 rounded-full border border-cyan-300/60 object-cover ring-4 ring-cyan-400/10 shadow-[0_0_40px_-8px_rgba(24,224,255,0.5)]"
          />
        </div>

        <p className="mb-6 inline-flex items-center gap-2 rounded-full border border-cyan-400/20 bg-cyan-400/5 px-3.5 py-1.5 font-mono text-[10px] tracking-[0.2em] text-cyan-300 sm:text-xs">
          <span className="relative flex size-2" aria-hidden="true">
            <span className="absolute inline-flex size-full animate-ping rounded-full bg-cyan-400 opacity-60" />
            <span className="relative inline-flex size-2 rounded-full bg-cyan-400" />
          </span>
          MINECRAFT DEVELOPER {'·'} PYTHON BOT CODER
        </p>

        <h1 id="hero-title" className="text-balance text-4xl font-bold leading-[1.08] tracking-tight sm:text-5xl lg:text-6xl">
          Custom <span className="text-neon">Minecraft gamemodes</span> and custom{' '}
          <span className="text-neon">Python Discord bots.</span>
        </h1>

        <p className="mx-auto mt-7 max-w-2xl text-pretty text-base leading-relaxed text-muted-foreground md:text-lg">
          {"Hey, I'm "}
          <span className="font-semibold text-foreground">Lessert33pol</span>. I build complete BoxPvP, Lifesteal, and custom economy servers from scratch, write clean Skripts, and code custom Discord bots. Self-taught, hands-on, and zero copy-paste setups.
        </p>

        <div className="mt-9 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <a
            href="#gamemodes"
            className="inline-flex items-center justify-center gap-2 rounded-md bg-cyan-400 px-6 py-3 text-sm font-semibold text-[#021318] shadow-[0_0_36px_-8px_rgba(24,224,255,0.75)] transition-all hover:-translate-y-0.5 hover:bg-cyan-300 hover:shadow-[0_0_46px_-6px_rgba(24,224,255,0.9)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-400"
          >
            {'See What I Build ↓'}
          </a>
          <button
            type="button"
            onClick={copyDiscord}
            className="inline-flex items-center justify-center gap-2 rounded-md border border-cyan-400/40 bg-cyan-400/[0.03] px-6 py-3 text-sm font-semibold text-cyan-300 transition-all hover:-translate-y-0.5 hover:border-cyan-400/70 hover:bg-cyan-400/10 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-400"
          >
            Contact on Discord
            <ArrowUpRight className="size-4" aria-hidden="true" />
          </button>
        </div>
      </div>

      {/* profile card with the 3D skin viewer */}
      <div className="relative mx-auto mt-16 max-w-3xl">
        <div aria-hidden="true" className="absolute -inset-6 -z-10 bg-gradient-to-br from-cyan-500/10 via-transparent to-violet-500/10 blur-3xl" />
        <div className="glass relative overflow-hidden text-left">
          <div className="grid md:grid-cols-[minmax(0,17rem)_1fr]">
            {/* skin portrait stage */}
            <div className="relative flex h-80 items-center justify-center overflow-hidden border-b border-white/10 md:h-auto md:min-h-[26rem] md:border-r md:border-b-0">
              <div aria-hidden="true" className="neon-grid absolute inset-0 opacity-50" />
              <div aria-hidden="true" className="absolute top-1/2 left-1/2 size-60 -translate-x-1/2 -translate-y-1/2 rounded-full bg-cyan-400/15 blur-3xl" />
              <div aria-hidden="true" className="absolute bottom-7 left-1/2 h-4 w-40 -translate-x-1/2 rounded-[50%] bg-cyan-400/25 blur-lg" />
              <img
                src="/images/gojo.png"
                alt="Lessert33pol's Minecraft skin"
                className="animate-float relative h-64 w-auto object-contain drop-shadow-[0_14px_30px_rgba(24,224,255,0.22)] md:h-72"
              />
            </div>

            {/* Profile panel */}
            <div className="relative flex flex-col justify-center bg-black/30 p-6 md:p-8">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="truncate font-display text-xl font-bold tracking-tight">Lessert33pol</p>
                  <p className="mt-0.5 font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
                    Minecraft Dev {'·'} Python Bot Coder
                  </p>
                </div>
                <span className="flex shrink-0 items-center gap-1.5 rounded-full border border-cyan-400/30 bg-cyan-400/10 px-2.5 py-1 font-mono text-[11px] text-cyan-300">
                  <span className="relative flex size-2" aria-hidden="true">
                    <span className="absolute inline-flex size-full animate-ping rounded-full bg-cyan-400 opacity-60" />
                    <span className="relative inline-flex size-2 rounded-full bg-cyan-400" />
                  </span>
                  {'•'} online
                </span>
              </div>

              <dl className="mt-6 grid grid-cols-3 gap-2">
                {[
                  ['7', 'Servers'],
                  ['2', 'Gamemodes'],
                  ['Self', 'Taught'],
                ].map(([value, label]) => (
                  <div key={label} className="rounded-md border border-white/10 bg-white/[0.03] p-3 text-center">
                    <dd className="font-mono text-lg font-bold text-cyan-300">{value}</dd>
                    <dt className="mt-0.5 text-[10px] uppercase tracking-wider text-muted-foreground">{label}</dt>
                  </div>
                ))}
              </dl>

              <ul className="mt-6 flex flex-wrap gap-1.5">
                {['Skript', 'Python', 'BoxPvP', 'Lifesteal', 'Vault'].map((tag) => (
                  <li
                    key={tag}
                    className="rounded-full border border-cyan-400/20 bg-cyan-400/5 px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-cyan-300/90"
                  >
                    {tag}
                  </li>
                ))}
              </ul>

              <p className="mt-6 font-mono text-[11px] text-muted-foreground">player://lessert33pol</p>
            </div>
          </div>
        </div>
      </div>

      {/* scroll hint */}
      <div aria-hidden="true" className="mt-14 flex flex-col items-center gap-2 font-mono text-[10px] tracking-[0.3em] text-muted-foreground/70">
        SCROLL
        <span className="relative block h-10 w-px bg-gradient-to-b from-cyan-400/40 to-transparent">
          <span className="animate-scroll-hint absolute -left-[1.5px] top-0 size-1 rounded-full bg-cyan-400" />
        </span>
      </div>
    </section>
  )
}
