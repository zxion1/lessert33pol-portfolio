import { Coins, Gavel, Heart, ShieldCheck, Swords, TrendingUp } from 'lucide-react'
import { SectionHeading } from './section-heading'

const pillars = [
  {
    icon: Heart,
    step: 'STAGE 01',
    title: 'Heart Transfer & Limits',
    body: 'Heart-steal transfer on kill, configurable max-heart limits, and heart withdraw items that can be traded or stored.',
    tags: ['Heart Steal', 'Max Hearts', 'Heart Items'],
  },
  {
    icon: ShieldCheck,
    step: 'STAGE 02',
    title: 'Death Bans & Revive Beacons',
    body: 'Death ban or spectator rules when a player hits zero, plus tiered craftable revive beacons that bring teammates back at a real cost.',
    tags: ['Death Ban', 'Spectator Mode', 'Revive Beacons'],
  },
  {
    icon: Coins,
    step: 'STAGE 03',
    title: 'Vault Economy',
    body: 'Money sinks that actually drain, player shops, an auction house, crates, and kill-streak bounties tuned so prices hold over a full season.',
    tags: ['Shops', 'Auction House', 'Bounties', 'Vault'],
  },
  {
    icon: ShieldCheck,
    step: 'STAGE 04',
    title: 'Anti-Dupe & Combat-Log',
    body: 'Anti-dupe checks on every heart item, combat-log punishment, alt-farm detection, and pre-generated worlds behind a clean border.',
    tags: ['Anti-Dupe', 'Combat Log', 'Anti Alt-Farm', 'Pregen'],
  },
]

const stats = [
  { value: '100%', label: 'Custom', accent: 'text-cyan-300' },
  { value: '20', label: 'Max Hearts', accent: 'text-rose-300' },
  { value: '4', label: 'Core Stages', accent: 'text-violet-300' },
  { value: '0', label: 'Dupes', accent: 'text-amber-300' },
]

const listings = [
  { item: 'Heart Item x1', seller: 'Steve_PvP', price: '$25,000' },
  { item: 'Revive Beacon', seller: 'xKiller', price: '$180,000' },
  { item: 'Netherite Set', seller: 'Ghost_09', price: '$72,500' },
]

const feed = [
  { text: 'Ghost_09 slain by xKiller', delta: '+1', tone: 'text-rose-300' },
  { text: 'Bounty claimed on Steve_PvP', delta: '$10K', tone: 'text-amber-300' },
  { text: 'Lumi withdrew a heart', delta: '-1', tone: 'text-muted-foreground' },
]

function HeartBar() {
  return (
    <div className="glass bg-black/30 p-5">
      <div className="mb-4 flex items-center justify-between">
        <span className="font-mono text-xs tracking-widest text-muted-foreground">HEALTH</span>
        <span className="font-mono text-xs text-rose-300">14 / 20 hearts</span>
      </div>
      <div className="flex flex-wrap gap-1.5" aria-hidden="true">
        {Array.from({ length: 20 }).map((_, i) => (
          <Heart
            key={i}
            className={`size-5 ${
              i < 14 ? 'fill-rose-500 text-rose-500 drop-shadow-[0_0_6px_rgba(244,63,94,0.7)]' : 'text-white/15'
            } ${i === 13 ? 'animate-heartbeat' : ''}`}
          />
        ))}
      </div>
      <ul className="mt-5 space-y-2 border-t border-white/10 pt-4">
        {feed.map(({ text, delta, tone }) => (
          <li key={text} className="flex items-center justify-between gap-3 font-mono text-xs">
            <span className="truncate text-foreground/80">{text}</span>
            <span className={`shrink-0 ${tone}`}>{delta}</span>
          </li>
        ))}
      </ul>
    </div>
  )
}

function AuctionBoard() {
  return (
    <div className="glass bg-black/30 p-5">
      <div className="mb-4 flex items-center justify-between">
        <span className="inline-flex items-center gap-2 font-mono text-xs tracking-widest text-muted-foreground">
          <Gavel className="size-3.5 text-amber-300" aria-hidden="true" />
          /AH LIVE
        </span>
        <span className="inline-flex items-center gap-1 font-mono text-xs text-cyan-300">
          <TrendingUp className="size-3.5" aria-hidden="true" />
          Stable economy
        </span>
      </div>
      <table className="w-full text-left font-mono text-xs">
        <caption className="sr-only">Example auction house listings</caption>
        <thead>
          <tr className="text-muted-foreground">
            <th scope="col" className="pb-2 font-normal">Item</th>
            <th scope="col" className="pb-2 font-normal">Seller</th>
            <th scope="col" className="pb-2 text-right font-normal">Price</th>
          </tr>
        </thead>
        <tbody>
          {listings.map(({ item, seller, price }) => (
            <tr key={item} className="border-t border-white/5">
              <td className="py-2.5 text-foreground">{item}</td>
              <td className="py-2.5 text-muted-foreground">{seller}</td>
              <td className="py-2.5 text-right text-amber-300">{price}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="mt-4 grid grid-cols-2 gap-2 border-t border-white/10 pt-4 font-mono text-xs">
        <div className="rounded-md border border-white/10 bg-white/[0.03] p-2.5">
          <p className="text-muted-foreground">Money Sinks</p>
          <p className="mt-1 text-foreground">Shops, Crates, Repairs</p>
        </div>
        <div className="rounded-md border border-white/10 bg-white/[0.03] p-2.5">
          <p className="text-muted-foreground">Faucets</p>
          <p className="mt-1 text-foreground">Kills, Bounties, Jobs</p>
        </div>
      </div>
    </div>
  )
}

export function Lifesteal() {
  return (
    <section id="lifesteal" aria-labelledby="lifesteal-title" className="px-4 py-20 md:py-28">
      <div className="mx-auto max-w-6xl">
        <div className="glass relative overflow-hidden border-rose-400/15 p-6 md:p-12">
          <div aria-hidden="true" className="absolute -top-32 -right-24 size-96 rounded-full bg-rose-500/15 blur-[100px]" />
          <div aria-hidden="true" className="absolute -bottom-32 -left-24 size-96 rounded-full bg-amber-500/10 blur-[100px]" />

          <div className="relative">
            <SectionHeading
              id="lifesteal-title"
              index="04"
              eyebrow="Lifesteal"
              title={
                <>
                  Lifesteal{' '}
                  <span className="bg-gradient-to-r from-rose-300 via-rose-400 to-amber-300 bg-clip-text text-transparent">
                    &amp; Economy
                  </span>
                </>
              }
              description="Hardcore survival where every heart counts. Complete Lifesteal servers with a balanced economy, fair combat, and airtight anti-abuse — built from the ground up."
            />

            <dl className="mb-8 grid grid-cols-2 gap-3 md:grid-cols-4">
              {stats.map(({ value, label, accent }) => (
                <div key={label} className="flex flex-col rounded-lg border border-white/10 bg-black/30 p-4 text-center">
                  <dt className="order-last mt-1 text-[11px] uppercase tracking-wider text-muted-foreground">{label}</dt>
                  <dd className={`font-mono text-2xl font-bold md:text-3xl ${accent}`}>{value}</dd>
                </div>
              ))}
            </dl>

            <div className="mb-8 grid gap-4 md:grid-cols-2">
              <HeartBar />
              <AuctionBoard />
            </div>

            <ol className="grid gap-4 md:grid-cols-2">
              {pillars.map(({ icon: Icon, step, title, body, tags }) => (
                <li key={title} className="glass glass-hover group bg-black/30 p-6 md:p-7">
                  <div className="mb-5 flex items-center justify-between">
                    <span className="inline-flex size-12 items-center justify-center rounded-lg border border-rose-400/25 bg-rose-400/10 text-rose-300 transition-shadow group-hover:shadow-[0_0_24px_-2px_rgba(244,63,94,0.55)]">
                      <Icon className="size-6" aria-hidden="true" />
                    </span>
                    <span className="font-mono text-xs tracking-widest text-violet-300/80">{step}</span>
                  </div>
                  <h3 className="mb-2 text-lg font-semibold md:text-xl">{title}</h3>
                  <p className="mb-5 leading-relaxed text-muted-foreground">{body}</p>
                  <ul className="flex flex-wrap gap-2" aria-label={`${title} features`}>
                    {tags.map((tag) => (
                      <li
                        key={tag}
                        className="rounded-md border border-white/10 bg-white/[0.04] px-2.5 py-1 font-mono text-[11px] text-foreground/80"
                      >
                        {tag}
                      </li>
                    ))}
                  </ul>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </div>
    </section>
  )
}
