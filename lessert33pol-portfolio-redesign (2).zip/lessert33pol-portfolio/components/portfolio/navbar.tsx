'use client'

import { Check, Copy, Menu, X } from 'lucide-react'
import { useEffect, useState } from 'react'
import { useDiscordCopy } from './discord-copy-provider'

const links = [
  { href: '#about', label: 'About' },
  { href: '#gamemodes', label: 'Gamemodes' },
  { href: '#boxpvp', label: 'BoxPvP' },
  { href: '#lifesteal', label: 'Lifesteal & Economy' },
  { href: '#bots', label: 'Discord Bots' },
  { href: '#skills', label: 'Skills' },
  { href: '#experience', label: 'Experience' },
  { href: '#contact', label: 'Contact' },
]

function CopyDiscordButton({ className = '' }: { className?: string }) {
  const { copyDiscord, copied } = useDiscordCopy()
  return (
    <button
      type="button"
      onClick={copyDiscord}
      className={`inline-flex items-center justify-center gap-2 rounded-md border border-cyan-400/40 px-4 py-1.5 font-mono text-[11px] uppercase tracking-[0.18em] text-cyan-300 transition-all hover:border-cyan-400/70 hover:bg-cyan-400/10 hover:shadow-[0_0_24px_-6px_rgba(24,224,255,0.6)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-400 ${className}`}
    >
      {copied ? <Check className="size-3.5" aria-hidden="true" /> : <Copy className="size-3.5" aria-hidden="true" />}
      {copied ? 'Copied!' : 'Copy Discord'}
    </button>
  )
}

export function Navbar() {
  const [open, setOpen] = useState(false)
  const [active, setActive] = useState<string>('')

  useEffect(() => {
    const ids = ['home', ...links.map((l) => l.href.slice(1))]
    const sections = ids.map((id) => document.getElementById(id)).filter((el): el is HTMLElement => !!el)
    const visible = new Map<string, number>()

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) visible.set(entry.target.id, entry.intersectionRatio)
          else visible.delete(entry.target.id)
        }
        // pick the visible section that appears first in page order
        const current = ids.find((id) => visible.has(id))
        if (current) setActive(current === 'home' ? '' : current)
      },
      { rootMargin: '-35% 0px -55% 0px', threshold: [0, 0.1, 0.5, 1] },
    )

    sections.forEach((el) => observer.observe(el))
    return () => observer.disconnect()
  }, [])

  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-cyan-400/10 bg-[#05060f]/75 backdrop-blur-xl">
      <nav aria-label="Primary" className="mx-auto flex h-14 max-w-7xl items-center justify-between gap-4 px-4 md:px-6">
        <a href="#home" className="flex items-center gap-2.5 font-display text-sm font-bold tracking-tight">
          <img
            src="/images/avatar.png"
            alt=""
            width={28}
            height={28}
            className="size-7 rounded-full border border-cyan-400/40 object-cover"
          />
          <span>
            Lessert<span className="text-cyan-400">33pol</span>
          </span>
        </a>

        <ul className="hidden items-center gap-0.5 xl:flex">
          {links.map((link) => {
            const isActive = active === link.href.slice(1)
            return (
              <li key={link.href}>
                <a
                  href={link.href}
                  aria-current={isActive ? 'true' : undefined}
                  className={`relative block px-2.5 py-2 font-mono text-[11px] uppercase tracking-[0.14em] transition-colors duration-300 ${
                    isActive ? 'text-cyan-300' : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {link.label}
                  <span
                    aria-hidden="true"
                    className={`pointer-events-none absolute inset-x-2.5 -bottom-[11px] h-px origin-center bg-cyan-400 shadow-[0_0_10px_1px_rgba(24,224,255,0.7)] transition-all duration-300 ${
                      isActive ? 'scale-x-100 opacity-100' : 'scale-x-0 opacity-0'
                    }`}
                  />
                </a>
              </li>
            )
          })}
        </ul>

        <div className="flex items-center gap-2">
          <CopyDiscordButton className="hidden sm:inline-flex" />
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-controls="mobile-menu"
            className="inline-flex size-9 items-center justify-center rounded-md border border-white/10 text-foreground transition-colors hover:bg-white/5 xl:hidden"
          >
            {open ? <X className="size-5" aria-hidden="true" /> : <Menu className="size-5" aria-hidden="true" />}
            <span className="sr-only">{open ? 'Close menu' : 'Open menu'}</span>
          </button>
        </div>
      </nav>

      {open ? (
        <div id="mobile-menu" className="border-t border-cyan-400/10 bg-[#05060f]/95 px-4 pb-4 pt-2 xl:hidden">
          <ul className="mx-auto flex max-w-7xl flex-col">
            {links.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className={`block rounded-md px-3 py-2.5 font-mono text-xs uppercase tracking-[0.14em] transition-colors hover:bg-white/5 ${
                    active === link.href.slice(1) ? 'text-cyan-300' : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
          <CopyDiscordButton className="mt-2 w-full sm:hidden" />
        </div>
      ) : null}
    </header>
  )
}
