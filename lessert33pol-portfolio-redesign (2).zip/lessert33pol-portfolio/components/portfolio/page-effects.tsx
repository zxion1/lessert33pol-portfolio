'use client'

import { ArrowUp } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'

/** Scroll progress bars, cursor spotlight on .glass panels and a back-to-top button. */
export function PageEffects() {
  const bar = useRef<HTMLDivElement>(null)
  const side = useRef<HTMLDivElement>(null)
  const [showTop, setShowTop] = useState(false)

  useEffect(() => {
    let frame = 0
    const update = () => {
      frame = 0
      const max = document.documentElement.scrollHeight - window.innerHeight
      const p = max > 0 ? Math.min(1, window.scrollY / max) : 0
      if (bar.current) bar.current.style.transform = `scaleX(${p})`
      if (side.current) side.current.style.transform = `scaleY(${p})`
      setShowTop(window.scrollY > 600)
    }
    const onScroll = () => {
      if (!frame) frame = requestAnimationFrame(update)
    }
    const onMove = (e: PointerEvent) => {
      const target = (e.target as HTMLElement | null)?.closest<HTMLElement>('.glass')
      if (!target) return
      const rect = target.getBoundingClientRect()
      target.style.setProperty('--mx', `${e.clientX - rect.left}px`)
      target.style.setProperty('--my', `${e.clientY - rect.top}px`)
    }
    update()
    window.addEventListener('scroll', onScroll, { passive: true })
    window.addEventListener('resize', onScroll)
    document.addEventListener('pointermove', onMove, { passive: true })
    return () => {
      window.removeEventListener('scroll', onScroll)
      window.removeEventListener('resize', onScroll)
      document.removeEventListener('pointermove', onMove)
      if (frame) cancelAnimationFrame(frame)
    }
  }, [])

  return (
    <>
      <div aria-hidden="true" className="pointer-events-none fixed inset-x-0 top-0 z-[70] h-[2px]">
        <div
          ref={bar}
          className="h-full origin-left bg-gradient-to-r from-cyan-400 via-cyan-200 to-violet-400 shadow-[0_0_12px_rgba(24,224,255,0.7)]"
          style={{ transform: 'scaleX(0)' }}
        />
      </div>
      <div aria-hidden="true" className="pointer-events-none fixed inset-y-0 right-0 z-[70] w-[3px]">
        <div
          ref={side}
          className="h-full origin-top bg-gradient-to-b from-cyan-400 to-violet-400 opacity-70 shadow-[0_0_12px_rgba(24,224,255,0.6)]"
          style={{ transform: 'scaleY(0)' }}
        />
      </div>
      <a
        href="#home"
        aria-label="Back to top"
        tabIndex={showTop ? 0 : -1}
        className={`fixed right-6 bottom-6 z-[55] grid size-10 place-items-center rounded-full border border-cyan-400/40 bg-[#05060f]/80 text-cyan-300 backdrop-blur transition-all duration-300 hover:bg-cyan-400/10 hover:shadow-[0_0_24px_-4px_rgba(24,224,255,0.6)] ${
          showTop ? 'translate-y-0 opacity-100' : 'pointer-events-none translate-y-3 opacity-0'
        }`}
      >
        <ArrowUp className="size-4" aria-hidden="true" />
      </a>
      <div
        aria-hidden="true"
        className="pointer-events-none fixed inset-0 -z-10 opacity-[0.03] mix-blend-overlay"
        style={{
          backgroundImage:
            "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='160' height='160'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>\")",
        }}
      />
    </>
  )
}
