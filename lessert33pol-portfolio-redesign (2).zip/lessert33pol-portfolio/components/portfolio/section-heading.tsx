type SectionHeadingProps = {
  index: string
  eyebrow: string
  title: React.ReactNode
  description?: React.ReactNode
  id: string
}

export function SectionHeading({ index, eyebrow, title, description, id }: SectionHeadingProps) {
  return (
    <div className="mb-12">
      <div className="flex items-center gap-3 sm:gap-4">
        <span className="font-mono text-sm text-cyan-400">{index}.</span>
        <h2 id={id} className="min-w-0 text-balance text-3xl font-bold tracking-tight md:text-4xl">
          {title}
        </h2>
        <span aria-hidden="true" className="hidden h-px min-w-12 flex-1 bg-gradient-to-r from-cyan-400/30 to-transparent md:block" />
      </div>
      <p className="mt-2 pl-8 font-mono text-xs text-muted-foreground sm:pl-9">{'// '}{eyebrow.toLowerCase()}</p>
      {description ? (
        <p className="mt-6 max-w-2xl text-pretty leading-relaxed text-muted-foreground md:text-lg">{description}</p>
      ) : null}
    </div>
  )
}
