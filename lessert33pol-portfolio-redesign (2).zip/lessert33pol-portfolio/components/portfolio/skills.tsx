'use client'

import {
  Activity,
  Bot,
  Boxes,
  Code2,
  Coins,
  Flame,
  Gavel,
  Gauge,
  Ghost,
  Globe,
  Hammer,
  Heart,
  KeyRound,
  Layers,
  LayoutGrid,
  Lock,
  Package,
  Pickaxe,
  Repeat,
  Server,
  Shield,
  ShieldCheck,
  ShoppingCart,
  Skull,
  Store,
  Swords,
  Target,
  Terminal,
  Timer,
  Users,
  Wallet,
  Zap,
} from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import { useState } from 'react'
import { SectionHeading } from './section-heading'

type CategoryKey = 'server' | 'boxpvp' | 'lifesteal' | 'economy' | 'security' | 'bots'

const categories: Record<CategoryKey, { label: string; chip: string; icon: string }> = {
  server: {
    label: 'Server',
    chip: 'border-cyan-400/25 bg-cyan-400/10 text-cyan-300',
    icon: 'bg-cyan-400/10 text-cyan-300',
  },
  boxpvp: {
    label: 'BoxPvP',
    chip: 'border-violet-400/25 bg-violet-400/10 text-violet-300',
    icon: 'bg-violet-400/10 text-violet-300',
  },
  lifesteal: {
    label: 'Lifesteal',
    chip: 'border-rose-400/25 bg-rose-400/10 text-rose-300',
    icon: 'bg-rose-400/10 text-rose-300',
  },
  economy: {
    label: 'Economy',
    chip: 'border-amber-400/25 bg-amber-400/10 text-amber-300',
    icon: 'bg-amber-400/10 text-amber-300',
  },
  security: {
    label: 'Security',
    chip: 'border-emerald-400/25 bg-emerald-400/10 text-emerald-300',
    icon: 'bg-emerald-400/10 text-emerald-300',
  },
  bots: {
    label: 'Bots',
    chip: 'border-sky-400/25 bg-sky-400/10 text-sky-300',
    icon: 'bg-sky-400/10 text-sky-300',
  },
}

const skills: { label: string; icon: LucideIcon; cat: CategoryKey }[] = [
  // Server
  { label: 'Minecraft Dev', icon: Boxes, cat: 'server' },
  { label: 'Skript', icon: Code2, cat: 'server' },
  { label: 'Server Config', icon: Server, cat: 'server' },
  { label: 'TPS Tuning', icon: Gauge, cat: 'server' },
  { label: 'Entity Optimization', icon: Activity, cat: 'server' },
  { label: 'LuckPerms', icon: KeyRound, cat: 'server' },

  // BoxPvP
  { label: 'BoxPvP', icon: Pickaxe, cat: 'boxpvp' },
  { label: 'Mine Regen Loops', icon: Repeat, cat: 'boxpvp' },
  { label: 'Mine Tiers', icon: Layers, cat: 'boxpvp' },
  { label: 'Dynamic Drop Rates', icon: Zap, cat: 'boxpvp' },
  { label: 'Pickaxe Upgrades', icon: Hammer, cat: 'boxpvp' },
  { label: 'Upgrade GUIs', icon: LayoutGrid, cat: 'boxpvp' },
  { label: 'Token Shops', icon: Store, cat: 'boxpvp' },
  { label: 'Sell Shops', icon: ShoppingCart, cat: 'boxpvp' },
  { label: 'PvP Zones', icon: Swords, cat: 'boxpvp' },
  { label: 'Anti-Clean Barriers', icon: Shield, cat: 'boxpvp' },
  { label: 'Spawn Protection', icon: ShieldCheck, cat: 'boxpvp' },
  { label: 'Combat Tag', icon: Timer, cat: 'boxpvp' },
  { label: 'Armor Balancing', icon: Shield, cat: 'boxpvp' },

  // Lifesteal
  { label: 'Lifesteal SMP', icon: Heart, cat: 'lifesteal' },
  { label: 'Heart Steal', icon: Heart, cat: 'lifesteal' },
  { label: 'Max-Heart Limits', icon: Gauge, cat: 'lifesteal' },
  { label: 'Heart Items', icon: Package, cat: 'lifesteal' },
  { label: 'Death Ban', icon: Skull, cat: 'lifesteal' },
  { label: 'Spectator Mode', icon: Ghost, cat: 'lifesteal' },
  { label: 'Revive Beacons', icon: Flame, cat: 'lifesteal' },
  { label: 'Pregen Worlds', icon: Globe, cat: 'lifesteal' },

  // Economy
  { label: 'Economy Setups', icon: Coins, cat: 'economy' },
  { label: 'Vault API', icon: Wallet, cat: 'economy' },
  { label: 'Player Shops', icon: Store, cat: 'economy' },
  { label: 'Auction House', icon: Gavel, cat: 'economy' },
  { label: 'Bounties', icon: Target, cat: 'economy' },
  { label: 'Crates', icon: Package, cat: 'economy' },
  { label: 'Money Sinks & Faucets', icon: Coins, cat: 'economy' },

  // Security
  { label: 'Exploit Prevention', icon: ShieldCheck, cat: 'security' },
  { label: 'Anti-Dupe', icon: Lock, cat: 'security' },
  { label: 'Combat-Log Protection', icon: Swords, cat: 'security' },
  { label: 'Anti Alt-Farm', icon: Users, cat: 'security' },

  // Bots
  { label: 'Python', icon: Terminal, cat: 'bots' },
  { label: 'Discord.py', icon: Bot, cat: 'bots' },
  { label: 'Bot Web Dashboards', icon: LayoutGrid, cat: 'bots' },
]

const filters: { key: 'all' | CategoryKey; label: string }[] = [
  { key: 'all', label: 'All' },
  { key: 'server', label: 'Server' },
  { key: 'boxpvp', label: 'BoxPvP' },
  { key: 'lifesteal', label: 'Lifesteal' },
  { key: 'economy', label: 'Economy' },
  { key: 'security', label: 'Security' },
  { key: 'bots', label: 'Bots' },
]

export function Skills() {
  const [active, setActive] = useState<'all' | CategoryKey>('all')
  const visible = active === 'all' ? skills : skills.filter((s) => s.cat === active)

  return (
    <section id="skills" aria-labelledby="skills-title" className="px-4 py-20 md:py-28">
      <div className="mx-auto max-w-6xl">
        <SectionHeading id="skills-title" index="06" eyebrow="Skills" title="The toolkit." />

        <div role="group" aria-label="Filter skills by category" className="mb-8 flex flex-wrap gap-2">
          {filters.map(({ key, label }) => {
            const count = key === 'all' ? skills.length : skills.filter((s) => s.cat === key).length
            const isActive = active === key
            return (
              <button
                key={key}
                type="button"
                onClick={() => setActive(key)}
                aria-pressed={isActive}
                className={`inline-flex items-center gap-2 rounded-full border px-4 py-1.5 font-mono text-[11px] uppercase tracking-[0.14em] transition-all focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-400 ${
                  isActive
                    ? 'border-cyan-400 bg-cyan-400 text-[#021318] shadow-[0_0_24px_-6px_rgba(24,224,255,0.8)]'
                    : 'border-white/10 text-muted-foreground hover:border-cyan-400/40 hover:text-cyan-300'
                }`}
              >
                {label}
                <span className={isActive ? 'text-[#021318]/60' : 'text-muted-foreground/60'}>{count}</span>
              </button>
            )
          })}
        </div>

        <ul key={active} className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
          {visible.map(({ label, icon: Icon, cat }) => {
            const c = categories[cat]
            return (
              <li
                key={`${cat}-${label}`}
                className="glass glass-hover animate-in fade-in zoom-in-95 flex flex-col gap-3 p-4 duration-300"
              >
                <span className={`inline-flex size-9 items-center justify-center rounded-md ${c.icon}`}>
                  <Icon className="size-4" aria-hidden="true" />
                </span>
                <span className="text-sm font-semibold leading-snug">{label}</span>
                <span
                  className={`self-start rounded-full border px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider ${c.chip}`}
                >
                  {c.label}
                </span>
              </li>
            )
          })}
        </ul>

        <p className="mt-8 text-center font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground/70">
          {visible.length} / {skills.length} skills
        </p>
      </div>
    </section>
  )
}
