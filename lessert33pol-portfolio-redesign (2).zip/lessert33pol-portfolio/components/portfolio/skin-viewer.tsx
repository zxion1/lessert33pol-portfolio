'use client'

import { useEffect, useRef, useState } from 'react'
import type { SkinViewer as SkinViewerInstance } from 'skinview3d'

const animations = ['Idle', 'Walk', 'Run', 'Wave'] as const
type AnimationName = (typeof animations)[number]

export function SkinViewer() {
  const containerRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const viewerRef = useRef<SkinViewerInstance | null>(null)
  const libRef = useRef<typeof import('skinview3d') | null>(null)
  const [active, setActive] = useState<AnimationName>('Walk')
  const [ready, setReady] = useState(false)

  useEffect(() => {
    const container = containerRef.current
    const canvas = canvasRef.current
    if (!container || !canvas) return

    let disposed = false
    let observer: ResizeObserver | undefined

    import('skinview3d').then((lib) => {
      if (disposed) return
      libRef.current = lib
      const viewer = new lib.SkinViewer({
        canvas,
        width: container.clientWidth,
        height: container.clientHeight,
        skin: '/skins/lessert33pol.png',
        model: 'slim',
        zoom: 0.85,
        fov: 50,
      })
      viewer.background = null
      viewer.autoRotate = true
      viewer.autoRotateSpeed = 0.6
      viewer.controls.enableZoom = false
      viewer.controls.enablePan = false
      viewer.animation = new lib.WalkingAnimation()
      viewer.animation.speed = 0.7
      viewerRef.current = viewer
      setReady(true)

      observer = new ResizeObserver(() => {
        viewer.setSize(container.clientWidth, container.clientHeight)
      })
      observer.observe(container)
    })

    return () => {
      disposed = true
      observer?.disconnect()
      viewerRef.current?.dispose()
      viewerRef.current = null
    }
  }, [])

  function playAnimation(name: AnimationName) {
    const viewer = viewerRef.current
    const lib = libRef.current
    if (!viewer || !lib) return
    setActive(name)
    const map = {
      Idle: lib.IdleAnimation,
      Walk: lib.WalkingAnimation,
      Run: lib.RunningAnimation,
      Wave: lib.WaveAnimation,
    }
    viewer.animation = new map[name]()
    if (name === 'Walk') viewer.animation.speed = 0.7
  }

  return (
    <>
      <div ref={containerRef} className="absolute inset-x-0 top-14 bottom-4 cursor-grab active:cursor-grabbing">
        <canvas
          ref={canvasRef}
          role="img"
          aria-label="Interactive 3D model of Lessert33pol's Minecraft skin. Drag to rotate."
          className={`transition-opacity duration-700 ${ready ? 'opacity-100' : 'opacity-0'}`}
        />
      </div>
      <div
        role="group"
        aria-label="Skin animation"
        className="absolute inset-x-4 top-4 flex gap-1 rounded-lg border border-white/10 bg-black/40 p-1 backdrop-blur-md"
      >
        {animations.map((name) => (
          <button
            key={name}
            type="button"
            onClick={() => playAnimation(name)}
            aria-pressed={active === name}
            disabled={!ready}
            className={`flex-1 rounded-md px-2 py-1.5 font-mono text-[11px] uppercase tracking-wider transition-colors focus-visible:outline-2 focus-visible:outline-cyan-400 ${
              active === name
                ? 'bg-cyan-400/15 text-cyan-300'
                : 'text-muted-foreground hover:bg-white/5 hover:text-foreground'
            }`}
          >
            {name}
          </button>
        ))}
      </div>
    </>
  )
}
