'use client'

import { useEffect, useRef } from 'react'

type Star = { x: number; y: number; r: number; a: number; tw: number; sq: boolean; depth: number }

/** Twinkling starfield with a light scroll parallax, drawn on a single canvas. */
export function Starfield() {
  const ref = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = ref.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    const dpr = Math.min(window.devicePixelRatio || 1, 2)
    let w = 0
    let h = 0
    let raf = 0
    let scrollY = window.scrollY
    let stars: Star[] = []

    const build = () => {
      w = window.innerWidth
      h = window.innerHeight
      canvas.width = Math.floor(w * dpr)
      canvas.height = Math.floor(h * dpr)
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      const count = Math.min(240, Math.floor((w * h) / 9000))
      stars = Array.from({ length: count }, () => {
        const sq = Math.random() < 0.05
        return {
          x: Math.random() * w,
          y: Math.random() * h,
          r: sq ? 1.6 + Math.random() * 2.2 : 0.4 + Math.random() * 1.1,
          a: 0.25 + Math.random() * 0.65,
          tw: Math.random() * Math.PI * 2,
          sq,
          depth: 0.02 + Math.random() * 0.08,
        }
      })
    }

    const draw = (t: number) => {
      ctx.clearRect(0, 0, w, h)
      for (const s of stars) {
        const twinkle = reduce ? 1 : 0.65 + 0.35 * Math.sin(t / 1200 + s.tw)
        const y = (((s.y - scrollY * s.depth) % h) + h) % h
        ctx.globalAlpha = s.a * twinkle
        ctx.fillStyle = s.sq ? '#5fd0d8' : '#c9d6ff'
        if (s.sq) {
          ctx.fillRect(s.x, y, s.r, s.r)
        } else {
          ctx.beginPath()
          ctx.arc(s.x, y, s.r, 0, Math.PI * 2)
          ctx.fill()
        }
      }
      ctx.globalAlpha = 1
      if (!reduce) raf = requestAnimationFrame(draw)
    }

    const onScroll = () => {
      scrollY = window.scrollY
      if (reduce) draw(0)
    }
    const onResize = () => {
      build()
      if (reduce) draw(0)
    }

    build()
    draw(0)
    if (!reduce) raf = requestAnimationFrame(draw)
    window.addEventListener('scroll', onScroll, { passive: true })
    window.addEventListener('resize', onResize)
    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('scroll', onScroll)
      window.removeEventListener('resize', onResize)
    }
  }, [])

  return <canvas ref={ref} aria-hidden="true" className="absolute inset-0 size-full" />
}
