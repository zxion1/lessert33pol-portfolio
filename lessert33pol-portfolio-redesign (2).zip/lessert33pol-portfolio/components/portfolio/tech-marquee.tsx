const items = [
  'TPS OPTIMIZATION',
  'CUSTOM SKRIPT',
  'PYTHON 3',
  'DISCORD.PY',
  'PAPER / PURPUR',
  'LUCKPERMS',
  'BOXPVP ARCHITECTURE',
  'LIFESTEAL SMP',
  'VAULT ECONOMY',
  'WEB DASHBOARDS',
]

function Row({ hidden = false }: { hidden?: boolean }) {
  return (
    <ul aria-hidden={hidden || undefined} className="flex shrink-0 items-center gap-8 pr-8">
      {items.map((item) => (
        <li key={item} className="flex items-center gap-8 font-mono text-sm uppercase tracking-[0.2em] text-muted-foreground">
          [{item}]
          <span className="size-1.5 rotate-45 bg-cyan-400/60" aria-hidden="true" />
        </li>
      ))}
    </ul>
  )
}

export function TechMarquee() {
  return (
    <div
      aria-label="Technologies and specialties"
      className="relative overflow-hidden border-y border-white/5 bg-black/20 py-5 [mask-image:linear-gradient(90deg,transparent,black_12%,black_88%,transparent)]"
    >
      <div className="animate-marquee flex w-max motion-reduce:animate-none">
        <Row />
        <Row hidden />
      </div>
    </div>
  )
}
